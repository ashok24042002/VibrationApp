package com.example.vibrationapp;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
public class MainActivity5 extends AppCompatActivity {
    private EditText mEditTextName;
    private EditText mEditAge;
    private RadioGroup mRadioGroupGender;
    private DatePicker mDatePicker;
    private Spinner mSpinnerType;
    private SimpleDateFormat mDateFormat;
    private ArrayList<String> mFormData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        mEditTextName = findViewById(R.id.input_name);
        mEditAge = findViewById(R.id.input_age);
        mRadioGroupGender = findViewById(R.id.radio_group);
        mDatePicker = findViewById(R.id.date_picker_dob);
        mSpinnerType = findViewById(R.id.spinner_department);

        mFormData = new ArrayList<>();

        // ...

        Button buttonSubmit = findViewById(R.id.button_submit);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mEditTextName.getText().toString();
                mFormData.add(name);

                String age = mEditAge.getText().toString();
                mFormData.add(age);

                int selectedRadioButtonID = mRadioGroupGender.getCheckedRadioButtonId();
                RadioButton selectedRadioButton = findViewById(selectedRadioButtonID);
                String condition = selectedRadioButton.getText().toString();
                mFormData.add(condition);

                String selectedItem = mSpinnerType.getSelectedItem().toString();
                mFormData.add(selectedItem);

                mDatePicker = findViewById(R.id.date_picker_dob);
                int year = mDatePicker.getYear();
                int month = mDatePicker.getMonth()+1;
                int day = mDatePicker.getDayOfMonth();
                String date=""+day+"/"+month+"/"+year;
                mFormData.add(date);
                // Do something with the form data, for example, log it
                Log.d("FormData", mFormData.toString());
                mFormData.clear();
                mEditTextName.setText("");
                mEditAge.setText("");
                mRadioGroupGender.clearCheck();
                mSpinnerType.setSelection(0);
                Toast.makeText(getApplicationContext(), "Data Recorded", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
