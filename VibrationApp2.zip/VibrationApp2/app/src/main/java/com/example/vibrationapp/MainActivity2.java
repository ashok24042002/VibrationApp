package com.example.vibrationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    private Button showFrame;
    private Button showLinear;
    private Button showRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        showFrame=(Button) findViewById(R.id.btnFrame);
        showFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveAct3();
            }
        });
        showLinear=(Button) findViewById(R.id.btnLinear);
        showLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveAct4();
            }
        });
        showRegister=(Button) findViewById(R.id.btnRegister);
        showRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveAct5();
            }
        });

    }

    private void moveAct3(){
        Intent intent = new Intent(this,MainActivity3.class);
        startActivity(intent);
    }
    private void moveAct4(){
        Intent intent = new Intent(this,MainActivity4.class);
        startActivity(intent);
    }
    private void moveAct5(){
        Intent intent = new Intent(this,MainActivity5.class);
        startActivity(intent);
    }
}